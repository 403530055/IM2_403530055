package easter;

public class EasterTester {
	
	public static void main(String []arg){
		Easter easter_2001 = new Easter(2001,0,0);
		Easter easter_2012 = new Easter(2012,0,0);
		
		System.out.println(easter_2001.calculateEaster());
		System.out.println(easter_2012.calculateEaster());
	}
}
