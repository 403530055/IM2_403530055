package easter;

public class EasterTester {
	
	public static void main(String []arg){
		
		
		System.out.println(Easter.calculateEaster(2001));
		System.out.println(Easter.calculateEaster(2012));
		
	}
}
