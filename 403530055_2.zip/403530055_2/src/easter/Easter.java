package easter;

public class Easter {
	
		int aYear,month_easter,day_easter;
		
		Easter(){
			
		}
		
		Easter(int aYear,int month_easter,int day_easter){
			this.aYear = aYear;
			this.month_easter = 0;
			this.day_easter = 0;
		}
		
		private void gauss_algorithm(){
			int a = this.aYear % 19,
					b = this.aYear / 100,
					c = this.aYear % 100,
					d = b / 4,
					e = b % 4,
					f = (b+8) / 25,
					g = (b-f+1) / 3,
					h = (19*a+b-d-g+15) % 30,
					i = c / 4,
					k = c % 4,
					l = (32+ 2*e + 2*i - h - k) % 7,
					m = (a + 11*h + 22*l) / 451;
			this.month_easter = ((h + l - 7*m + 114) / 31);
			this.day_easter = ((h + l - 7*m + 114) % 31)+1;
		}
		
		public String calculateEaster(){         //target 
			gauss_algorithm();
			return "In " + String.format("%d", this.aYear) + ", Easter Sunday is: month = "+ String.format("%d", this.month_easter) + " and day = " + String.format("%d",this.day_easter);
		}
	
}
