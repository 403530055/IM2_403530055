package bank;
import bank.BankAccount;

public class CheckingAccount extends BankAccount{
	
	private int withdrawals;
	
	public CheckingAccount (int accountNumber, double initialBalance){
		this.type = "checking";
		this.accountNumber = accountNumber;
		this.balance = initialBalance;
		this.withdrawals = 0;
	}

	
	public void withdraw(double amount){
		
		final int FREE_WITHDRAWALS = 9;
		
		super.withdraw(amount);
		withdrawals++;
		if(withdrawals > FREE_WITHDRAWALS)
			deductFees();
	}
	
	public void deductFees(){
		final double fee = 4.0;
		if(fee < getBalance())
			super.withdraw(fee);
	}
	
	public void monthEnd(){
		withdrawals = 0;
	}
}
