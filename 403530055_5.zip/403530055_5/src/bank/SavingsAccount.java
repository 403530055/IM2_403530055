package bank;
import bank.BankAccount;

public class SavingsAccount extends BankAccount{
	
	private double interestRate;
	private double minBalance;
	
	public SavingsAccount (int accountNumber, double initialBalance, double interestRate){
		this.type = "savings";
		this.accountNumber = accountNumber;
		this.balance = initialBalance;
		this.minBalance = initialBalance;
		this.interestRate = interestRate;
		
	}
	
	public void setInterestRate(double rate){
		this.interestRate = rate;
	}
	
	public void withdraw(double amount){
		super.withdraw(amount);
		double balance = getBalance();
		if(balance < minBalance)
			minBalance = balance;
	}
	
	public void monthEnd(){
		addInterest();
		minBalance =  getBalance();
	}
	
	public void addInterest(){
		double interest = minBalance * this.interestRate * 0.01;
		super.deposit(interest);
		
	}
}
